export enum BuyButtonsEnum {
  ENABLE,
  BUY,
  READY,
  NONE,
}
