export const REQUEST_SIZE = 100
